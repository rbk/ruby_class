# numbers

num = 42
puts "what is num : #{num.class}"
puts "what is 42 : #{42.class}"

new_num = num * 1000000000
puts "new num is a : #{new_num.class}"

puts "------------------------------"

f = 3.14
puts "what is f : #{f.class}"
puts "what is 3.14 : #{3.14.class}"

f = 1.2e10
f = 1e9

puts f